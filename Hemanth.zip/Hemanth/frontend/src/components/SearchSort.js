import React from 'react';

const SearchSort = () => {
    return (
        <div>
            {/* Search and Sort options go here */}
        </div>
    );
};

export default SearchSort;
